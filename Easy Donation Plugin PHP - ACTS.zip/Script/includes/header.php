<!--CSS FILES -->
<link rel="stylesheet" type="text/css" href="assets/css/reset.css" />
<link rel="stylesheet" type="text/css" href="assets/css/styles.css" />
<link rel="stylesheet" type="text/css" href="assets/css/select.css" />	 
<!--End CSS FILES -->

<!--Popup CSS Files include process -->
   <?php 
   if(!$installed){?>
   <link rel="stylesheet" type="text/css" href="assets/css/popup.css" />
   
  <?php  }else{ ?>
      
 <?php } ?>
   
  

<!--End Popup CSS Files include process -->