<!--JavaScript Files-->
<script src="//ajax.aspnetcdn.com/ajax/jQuery/jquery-1.11.1.min.js"></script> 
<script src="assets/js/validation.js"></script>     
<script type="text/javascript" src="assets/js/chosen.jquery.js"></script>
<script type="text/javascript" src="assets/js/effects.js"></script>
<script src="assets/js/jquery.dd.min.js"></script>
<script type="text/javascript" src="assets/js/popup.js"></script>
<!-- End JavaScript Files-->
